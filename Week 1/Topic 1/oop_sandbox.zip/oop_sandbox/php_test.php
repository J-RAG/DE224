<!doctype html>

<html lang="en">
  <head>
    <title>PHP Test Page</title>
    <meta charset="utf-8">
  </head>
  <body>

    <?php echo 'PHP is working!'; ?>

  </body>
</html>
